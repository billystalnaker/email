-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 11, 2015 at 10:21 PM
-- Server version: 5.5.42-37.1
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bstalnak_email`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_accounts`
--

CREATE TABLE IF NOT EXISTS `user_accounts` (
  `uacc_id` int(11) unsigned NOT NULL,
  `uacc_group_fk` smallint(5) unsigned NOT NULL DEFAULT '0',
  `uacc_email` varchar(100) NOT NULL DEFAULT '',
  `uacc_username` varchar(15) NOT NULL DEFAULT '',
  `uacc_password` varchar(60) NOT NULL DEFAULT '',
  `uacc_ip_address` varchar(40) NOT NULL DEFAULT '',
  `uacc_salt` varchar(40) NOT NULL DEFAULT '',
  `uacc_activation_token` varchar(40) NOT NULL DEFAULT '',
  `uacc_forgotten_password_token` varchar(40) NOT NULL DEFAULT '',
  `uacc_forgotten_password_expire` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uacc_update_email_token` varchar(40) NOT NULL DEFAULT '',
  `uacc_update_email` varchar(100) NOT NULL DEFAULT '',
  `uacc_active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `uacc_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `uacc_fail_login_attempts` smallint(5) NOT NULL DEFAULT '0',
  `uacc_fail_login_ip_address` varchar(40) NOT NULL DEFAULT '',
  `uacc_date_fail_login_ban` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Time user is banned until due to repeated failed logins',
  `uacc_date_last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uacc_date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `upro_first_name` varchar(25) NOT NULL,
  `upro_last_name` varchar(25) NOT NULL,
  `upro_date_registered` datetime NOT NULL,
  `upro_address_line1` varchar(75) NOT NULL,
  `upro_address_line2` varchar(75) NOT NULL,
  `upro_city` varchar(75) NOT NULL,
  `upro_state` varchar(50) NOT NULL,
  `upro_headshot_image_id` mediumint(8) NOT NULL,
  `upro_body_image_id` mediumint(8) NOT NULL,
  `upro_race` varchar(50) NOT NULL,
  `upro_height` varchar(50) NOT NULL,
  `upro_weight` varchar(50) NOT NULL,
  `upro_shoe_size` varchar(50) NOT NULL,
  `upro_shirt_size` varchar(50) NOT NULL,
  `upro_jacket_size` varchar(50) NOT NULL,
  `upro_pant_size` varchar(50) NOT NULL,
  `upro_pet` enum('None','Cat','Dog','Other') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `user_accounts`
--

TRUNCATE TABLE `user_accounts`;
--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_accounts`
--
ALTER TABLE `user_accounts`
  ADD PRIMARY KEY (`uacc_id`), ADD UNIQUE KEY `uacc_id` (`uacc_id`), ADD KEY `uacc_group_fk` (`uacc_group_fk`), ADD KEY `uacc_email` (`uacc_email`), ADD KEY `uacc_username` (`uacc_username`), ADD KEY `uacc_fail_login_ip_address` (`uacc_fail_login_ip_address`), ADD KEY `date_registered` (`upro_date_registered`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_accounts`
--
ALTER TABLE `user_accounts`
  MODIFY `uacc_id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


--
-- Dumping data for table `user_accounts`
--

INSERT INTO `user_accounts` ( `uacc_group_fk`, `uacc_email`, `uacc_username`, `uacc_password`, `uacc_ip_address`, `uacc_salt`, `uacc_activation_token`, `uacc_forgotten_password_token`, `uacc_forgotten_password_expire`, `uacc_update_email_token`, `uacc_update_email`, `uacc_active`, `uacc_suspend`, `uacc_fail_login_attempts`, `uacc_fail_login_ip_address`, `uacc_date_fail_login_ban`, `uacc_date_last_login`, `uacc_date_added`, `upro_first_name`, `upro_last_name`, `upro_date_registered`, `upro_address_line1`, `upro_address_line2`, `upro_city`, `upro_state`, `upro_headshot_image_id`, `upro_body_image_id`, `upro_race`, `upro_height`, `upro_weight`, `upro_shoe_size`, `upro_shirt_size`, `upro_jacket_size`, `upro_pant_size`, `upro_pet`) VALUES
( 1, 'zhooker@queensboro.com', 'zhooker', '$2a$08$Arzc2nWSqrNNva8KLZ/owejNYil9CdUHm1qRoQRAgcciegLPExAPq', '71.87.231.95', 'P72r3Sr7bMfsQj', '', '', '0000-00-00 00:00:00', '', '', 1, 0, 0, '', '0000-00-00 00:00:00', '2015-08-11 23:06:18', '2015-08-05 03:29:36', 'Zach', 'Hooker', '2015-08-05 03:29:36', '', '', '', '', 0, 0, '', '', '', '', '', '', '', 'None');
