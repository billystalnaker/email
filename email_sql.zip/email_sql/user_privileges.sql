-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 11, 2015 at 10:24 PM
-- Server version: 5.5.42-37.1
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bstalnak_email`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_privileges`
--

CREATE TABLE IF NOT EXISTS `user_privileges` (
  `upriv_id` smallint(5) NOT NULL,
  `upriv_name` varchar(40) NOT NULL DEFAULT '',
  `upriv_desc` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `user_privileges`
--

TRUNCATE TABLE `user_privileges`;--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_privileges`
--
ALTER TABLE `user_privileges`
  ADD PRIMARY KEY (`upriv_id`), ADD UNIQUE KEY `upriv_id` (`upriv_id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_privileges`
--
ALTER TABLE `user_privileges`
  MODIFY `upriv_id` smallint(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


--
-- Dumping data for table `user_privileges`
--

INSERT INTO `user_privileges` ( `upriv_name`, `upriv_desc`) VALUES
('Users', 'This is the User privilege'),
( 'Delete Users', 'Ability to delete users'),
( 'Delete Groups', 'Ability to delete groups'),
('Edit Privileges', 'Ability to edit privileges'),
('Delete Privileges', 'Ability to delete privileges'),
( 'Add Users', 'Ability to add users'),
('Privileges', 'Ability to manipulate privileges'),
('User Privileges', 'Ability to edit user privileges'),
('Group Privileges', 'Ability to edit group privileges'),
('Add Groups', 'Ability to add groups'),
( 'Add Privileges', 'Ability to add privileges'),
( 'Edit Users', 'Ability to edit users'),
( 'Edit Groups', 'Ability to edit groups'),
( 'View Groups', 'Ability to view groups'),
( 'View Users', 'Ability to view users'),
( 'View Privileges', 'Ability to view privileges'),
( 'Groups', 'Manipulate Groups'),
( 'Add Extras', 'Ability to add Extras into the system.'),
( 'Add Manifests', 'Add Manifests'),
( 'Edit Manifests', 'Edit Manifests'),
( 'Delete Manifests', 'Delete Manifests'),
('Edit Manifests', 'Edit Manifests'),
('View Manifests', 'View Manifests'),
('Manifest Users', 'Manipulate Manifest Users'),
('Blast Manifest', 'Ability to Blast a Manifest'),
('Manifests', 'Manipulate Manifests');

